using System;
using System.Drawing;

public abstract class Shape
{

	public Shape()
	{
	}

    public abstract void Export(Exporter exporter);
	
}